AMMA BIRTHDAY — LUXURY STORYBOOK EDITION

1. Extract this ZIP.
2. Keep index.html and the assets folder together.
3. Open index.html in Chrome, Edge, Firefox, or Safari.
4. Works offline and is mobile-friendly.

Personalized for Amma, born 5 August 1988.
With love from Cherry & Eshan.
